mucho espacio en blanco en el landing page 

asistencia con ia:
Application error: a client-side exception has occurred while loading asistencia-vehicular-ai.vercel.app (see the browser console for more information).

armar seed con usuarios existentes en producción 

los talleres no se ven con imagen

https://asistencia-vehicular-ai.vercel.app/dashboard/driver/history alinear componentes

https://asistencia-vehicular-ai.vercel.app/dashboard/request los servicios estan en ingles y los precios son iguales 150

el boton de cancelar solicitud no funciona

notificaciones push de tiquetera al aceptar y cancelar

